create function find_sportsmen_of_trainer(trainer integer, sport_level integer)
    returns TABLE(id integer, name character varying, s_sport_level integer, club character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT s.id,
               s.name,
               s."Sport_level",
               c."Name"
        FROM sport."Sportsmen" s
        inner join sport."Training" t on s.id = t."Sportsmen_id"
        inner join sport."Trainer" tr on t."Trainer_id" = tr."id"
        inner join sport."Sport_club" c on c.id=s."Club"
        WHERE (tr.id=trainer and s."Sport_level">=sport_level)
        ORDER BY s.id;
    END
$$;

alter function find_sportsmen_of_trainer(integer, integer) owner to postgres;


create function find_trainers_of_sport(sport integer)
    returns TABLE(id integer, name character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT tr.id,
               tr.Name
        FROM sport."Training" t
        inner join sport."Trainer" tr on tr.id = t."Trainer_id"
        WHERE (sport = t."Sport")
        ORDER BY tr.id;
 END
$$;

alter function find_trainers_of_sport(integer) owner to postgres;


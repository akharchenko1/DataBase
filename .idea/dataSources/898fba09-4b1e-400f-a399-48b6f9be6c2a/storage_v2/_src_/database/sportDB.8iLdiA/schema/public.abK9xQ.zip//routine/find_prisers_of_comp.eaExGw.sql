create function find_prisers_of_comp(comp integer)
    returns TABLE(id integer, name character varying, status integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT s.id,
               s.Name,
                r."status"
        FROM sport."Result" r
        inner join sport."Sportsmen" s on s.id = r."Sportsmen_id"
        WHERE comp = r."Comp_id" and r.status <= 3
        ORDER BY r.status;
 END
$$;

alter function find_prisers_of_comp(integer) owner to postgres;


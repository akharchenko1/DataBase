create function find_buildings(type character varying, first integer, second integer)
    returns TABLE(id integer, adress character varying, name character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT b.id,
               b.adress,
               b.name
        FROM sport."Building" b
        full join sport."stadium" s on b.id = s.id
        full join sport."swimming_pool" sp on sp.id = b.id
        WHERE b."Type"=type and ((s."Long">=first and s.count_people>=second) or (sp."Long">=first and sp.count_road>=second))
        ORDER BY b.id;
    END
$$;

alter function find_buildings(varchar, integer, integer) owner to postgres;


create function find_sportsmen_with_sports()
    returns TABLE(id integer, name character varying, s_sport_level integer, club character varying, sports integer, sport_name character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT s.id,
               s.name,
               s."Sport_level",
               c."Name",
               t."Sport",
               v."Name"
        FROM sport."Sportsmen" s
        inner join sport."Training" t on s.id = t."Sportsmen_id"
        inner join sport."View_of_sport" v on t."Sport" = v."id"
        inner join sport."Sport_club" c on c.id=s."Club" inner join find_dublers() f on f.id = s.id
        ORDER BY s.id;
    END
$$;

alter function find_sportsmen_with_sports() owner to postgres;


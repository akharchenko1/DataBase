create function find_sportsmen_in_competition_of_date_not(start_time_window date, finish_time_window date)
    returns TABLE(id_s integer, sportsmen character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT s.id,
                s.Name
        FROM  sport."Sportsmen" s left join find_clubs_in_competition_of_date(start_time_window,
finish_time_window) c on c.id_s = s.id
        WHERE c.id_s is null
        ORDER BY s.id;
 END
$$;

alter function find_sportsmen_in_competition_of_date_not(date, date) owner to postgres;


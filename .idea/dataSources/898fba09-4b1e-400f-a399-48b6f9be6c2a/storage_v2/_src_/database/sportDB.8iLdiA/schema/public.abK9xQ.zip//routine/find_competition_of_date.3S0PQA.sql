create function find_competition_of_date(start_time_window date, finish_time_window date, organisator integer)
    returns TABLE(id integer, name character varying, date date, id_o integer, organisators character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT c.id,
               c."Name",
               c."Date",
               o.id,
               o.name
        FROM sport."Competition" c
        inner join sport."Org_comp" o_c on c.id = o_c."Comp_id"
        inner join sport."Organisator" o on o_c."Org_id" = o."id"
        WHERE (( (organisator!=0 and o.id=organisator) or organisator = 0) and c."Date">=start_time_window and c."Date"<=finish_time_window)
        ORDER BY c.id;
 END
$$;

alter function find_competition_of_date(date, date, integer) owner to postgres;


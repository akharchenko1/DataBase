create function find_organisators_of_date(start_time_window date, finish_time_window date)
    returns TABLE(id integer, organisators character varying, count bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT f.id_o,
              f.organisators,
                count(f.id)
        FROM find_competition_of_date(
cast(start_time_window AS date),
cast(finish_time_window AS date),0
) f
        GROUP BY f.id_o, f.organisators;
 END
$$;

alter function find_organisators_of_date(date, date) owner to postgres;


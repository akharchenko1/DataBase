create function find_dublers()
    returns TABLE(id integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT t."Sportsmen_id"
        FROM sport."Training" t
        GROUP BY  t."Sportsmen_id"
        HAVING count(*)>1;
    END
$$;

alter function find_dublers() owner to postgres;


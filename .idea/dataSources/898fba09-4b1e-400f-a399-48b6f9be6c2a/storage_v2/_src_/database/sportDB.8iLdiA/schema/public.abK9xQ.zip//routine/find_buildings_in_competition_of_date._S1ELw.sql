create function find_buildings_in_competition_of_date(start_time_window date, finish_time_window date)
    returns TABLE(id integer, name character varying, type character varying, adress character varying, id_c integer, comp character varying, date date)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT b.id,
               b.Name,
               b."Type",
               b.adress,
               c.id,
                c."Name",
                c."Date"
        FROM sport."Competition" c
        inner join sport."Build_of_comp" b_o_c on c.id = b_o_c."Comp_id"
        inner join sport."Building" b on b_o_c."Build_id" = b.id
        WHERE (c."Date">=start_time_window and c."Date"<=finish_time_window)
        ORDER BY b.id;
 END
$$;

alter function find_buildings_in_competition_of_date(date, date) owner to postgres;


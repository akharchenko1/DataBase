create function find_clubs_in_competition_of_date(start_time_window date, finish_time_window date)
    returns TABLE(id integer, name character varying, id_s integer, sportsmen character varying, date date)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT s_c.id,
               s_c."Name",
               s.id,
                s.name,
               c."Date"
        FROM sport."Competition" c
        inner join sport."Result" r on c.id = r."Comp_id"
        inner join sport."Sportsmen" s on r."Sportsmen_id" = s."id"
        inner join sport."Sport_club" s_c on s_c.id = s."Club"
        WHERE (c."Date">=start_time_window and c."Date"<=finish_time_window)
        ORDER BY s_c.id;
 END
$$;

alter function find_clubs_in_competition_of_date(date, date) owner to postgres;


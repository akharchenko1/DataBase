create function find_trainers_of_sportsman(sportsman integer)
    returns TABLE(id integer, name character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT tr.id,
               tr.name
        FROM sport."Sportsmen" s
        inner join sport."Training" t on s.id = t."Sportsmen_id"
        inner join sport."Trainer" tr on t."Sport" = tr."id"
        WHERE sportsman = s.id
        ORDER BY tr.id;
 END
$$;

alter function find_trainers_of_sportsman(integer) owner to postgres;


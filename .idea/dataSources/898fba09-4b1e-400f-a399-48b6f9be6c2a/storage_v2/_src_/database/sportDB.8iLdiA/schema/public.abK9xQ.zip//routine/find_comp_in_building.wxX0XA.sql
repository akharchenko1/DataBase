create function find_comp_in_building(building integer, sport integer)
    returns TABLE(id integer, name character varying, sports character varying, date date)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT c.id,
               c."Name",
                v_o_s."Name",
                c."Date"
        FROM sport."Build_of_comp" b_o_c
        inner join sport."Competition" c on c.id = b_o_c."Comp_id"
        inner join sport."View_of_sport" v_o_s on v_o_s.id = c."Sport"
        WHERE ((((sport != 0) and v_o_s.id = sport) or sport = 0) and b_o_c."Build_id" = building)
        ORDER BY c.id;
 END
$$;

alter function find_comp_in_building(integer, integer) owner to postgres;

